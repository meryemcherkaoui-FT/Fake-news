# VeritAI v2.2 — Fake News Detection App (modèles réels du notebook)

Cette version de `app.py` **charge les vrais modèles et le vrai vectoriseur TF-IDF**
entraînés dans le notebook (`fake_news_detection_completed77__3_.ipynb`), au lieu
de réentraîner sur un dataset de démonstration synthétique.

## Architecture

```
veritai/
├── app.py                  ← API Flask (charge models/*.pkl)
├── index.html              ← Interface web (inchangée)
├── EXPORT_STATS_CELL.py    ← Cellule à coller dans le notebook (export accuracy)
├── README.md
└── models/                 ← A CREER : copier ici la sortie du notebook
    ├── tfidf_vectorizer.pkl
    ├── tfidf_vectorizer_xgb.pkl
    ├── naive_bayes.pkl
    ├── xgboost.pkl
    ├── sgd.pkl
    ├── svm_linearsvc.pkl
    ├── decision_tree.pkl
    ├── random_forest.pkl
    ├── logistic_regression.pkl
    └── model_stats.json    ← optionnel (accuracy de chaque modèle)
```

## Étapes pour récupérer les vrais modèles

1. **Exécuter le notebook** `fake_news_detection_completed77__3_.ipynb` jusqu'à la fin.
   La cellule 88 (`joblib.dump(...)`) crée automatiquement un dossier `models/`
   contenant le vectoriseur TF-IDF et les 7 modèles entraînés sur le vrai
   dataset (`Fake.csv` / `True.csv`).

2. **(Optionnel mais recommandé)** Ajouter le contenu de `EXPORT_STATS_CELL.py`
   comme nouvelle cellule à la fin du notebook (après la cellule 88) et
   l'exécuter. Cela crée `models/model_stats.json` avec les accuracies
   réelles de chaque modèle (issues de `df_results_full`, cellules 74-76).

3. **Copier le dossier `models/`** généré par le notebook à côté de `app.py`
   (même structure que ci-dessus).

4. **Lancer l'API** :
   ```bash
   pip install flask flask-cors scikit-learn xgboost nltk joblib numpy
   pip install pdfplumber python-docx   # optionnel, extraction fichiers
   pip install shap                     # optionnel, explicabilité

   python app.py
   # → http://localhost:5000
   ```

5. **Ouvrir `index.html`** dans le navigateur (l'interface est inchangée).

## Vérification

Au démarrage, `app.py` affiche dans la console quels fichiers ont été chargés :

```
  [OK] Naive Bayes            <- naive_bayes.pkl
  [OK] XGBoost                <- xgboost.pkl
  ...
Modeles reels charges depuis .../models | 7 modeles | NLTK lemmatisation: True
```

Vous pouvez aussi appeler `GET /api/status` : le champ `"ready": true` confirme
que les modèles réels sont bien chargés, et `"load_errors": []` doit être vide.
Si un fichier manque, il sera listé dans `load_errors` et `ready` restera `false`
tant que `tfidf_vectorizer.pkl` et au moins un modèle ne sont pas présents.

## Différences avec la v2.1 (modèles de démo)

| | v2.1 (démo) | v2.2 (réelle) |
|---|---|---|
| Données d'entraînement | Dataset synthétique généré au démarrage | Dataset ISOT réel (`Fake.csv` / `True.csv`) via le notebook |
| Entraînement | À chaque démarrage de `app.py` | Fait une fois dans le notebook, sauvegardé en `.pkl` |
| Accuracy affichée | Calculée sur données synthétiques | Chargée depuis `model_stats.json` (vrai test set) |
| Pipeline de nettoyage / TF-IDF / hyperparamètres | Identiques | Identiques |

Le pipeline de nettoyage (`clean_text`), la configuration TF-IDF
(`ngram_range=(1,2)`, `max_features=50000`, `min_df=2`, `sublinear_tf=True`,
+ TF-IDF dédié XGBoost à `max_features=10000`) et les hyperparamètres des
7 modèles restent strictement identiques au notebook — seule la **source des
modèles entraînés** change.
