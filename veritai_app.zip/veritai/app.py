"""
VeritAI — Fake News Detection API v2.2
Flask Backend — 7 modeles ML + SHAP + PDF/DOCX + Word Frequency
Cette version charge les VRAIS modeles/vectoriseurs entraines dans le notebook
(dossier models/, produit par la cellule "joblib.dump" du notebook), au lieu
de reentrainer sur un dataset de demonstration.
"""

import os, re, string, json, time, io, base64
import numpy as np
import joblib
from flask import Flask, request, jsonify
from flask_cors import CORS
import warnings; warnings.filterwarnings('ignore')

# ── ML ────────────────────────────────────────────────────────────────────────
from sklearn.feature_extraction.text import TfidfVectorizer  # noqa: F401 (utile si fallback)

try:
    from xgboost import XGBClassifier  # noqa: F401
    HAS_XGB = True
except ImportError:
    HAS_XGB = False

# ── NLTK (lemmatisation — aligné notebook) ────────────────────────────────────
try:
    import nltk
    nltk.download('stopwords', quiet=True)
    nltk.download('wordnet',   quiet=True)
    nltk.download('omw-1.4',   quiet=True)
    from nltk.corpus import stopwords as nltk_stopwords
    from nltk.stem import WordNetLemmatizer
    HAS_NLTK = True
    _lemmatizer  = WordNetLemmatizer()
    # Stopwords notebook : anglais NLTK + termes métier
    STOP_WORDS = set(nltk_stopwords.words('english')) | {
        'said', 'would', 'could', 'also', 'one', 'two', 'three',
        'us', 'reuters', 'news', 'u', 's'
    }
except Exception:
    HAS_NLTK = False
    _lemmatizer = None
    STOP_WORDS = {
        'the','a','an','and','or','but','in','on','at','to','for','of','is','are',
        'was','were','be','been','being','have','has','had','do','does','did',
        'will','would','could','should','may','might','this','that','these','those',
        'it','its','as','by','from','with','he','she','they','we','you','i',
        'his','her','their','our','your','my','not','no','so','if','than',
        'about','after','before','between','into','through','during','said',
        'also','more','other','up','out','what','when','who','which','how',
        'one','two','all','new','can','just','s','t','re','ve','ll','d','m'
    }

# ── Optional: SHAP ────────────────────────────────────────────────────────────
try:
    import shap  # noqa: F401
    HAS_SHAP = True
except ImportError:
    HAS_SHAP = False

# ── Optional: PDF extraction ──────────────────────────────────────────────────
try:
    import pdfplumber  # noqa: F401
    HAS_PDF = True
    HAS_PDFPLUMBER = True
except ImportError:
    try:
        import pypdf  # noqa: F401
        HAS_PDF = True
        HAS_PDFPLUMBER = False
    except ImportError:
        HAS_PDF = False
        HAS_PDFPLUMBER = False

# ── Optional: DOCX extraction ────────────────────────────────────────────────
try:
    import docx as python_docx  # noqa: F401
    HAS_DOCX = True
except ImportError:
    HAS_DOCX = False

app = Flask(__name__)
CORS(app)

# ── Chemins ───────────────────────────────────────────────────────────────────
BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
MODELS_DIR  = os.path.join(BASE_DIR, "models")

# Correspondance : nom affiche (UI) -> nom de fichier .pkl sauvegarde par le notebook
MODEL_FILES = {
    "Naive Bayes":          "naive_bayes.pkl",
    "XGBoost":              "xgboost.pkl",
    "SGDClassifier":        "sgd.pkl",
    "SVM (LinearSVC)":      "svm_linearsvc.pkl",
    "Decision Tree":        "decision_tree.pkl",
    "Random Forest":        "random_forest.pkl",
    "Logistic Regression":  "logistic_regression.pkl",
}
VECTORIZER_FILE     = "tfidf_vectorizer.pkl"
VECTORIZER_XGB_FILE = "tfidf_vectorizer_xgb.pkl"
STATS_FILE          = "model_stats.json"

# ── Globals ───────────────────────────────────────────────────────────────────
MODELS         = {}
VECTORIZER     = None   # pour NB, SGD, SVM, DT, RF, LR
VECTORIZER_XGB = None   # pour XGBoost (max_features=10000, sans min_df)
MODEL_STATS    = {}
IS_READY       = False
LOAD_ERRORS    = []

MODEL_META = {
    "Naive Bayes":          {"color":"#5B8DB8","desc":"Baseline probabiliste - rapide et interpretable"},
    "XGBoost":              {"color":"#E8874A","desc":"Gradient boosting - interactions non-lineaires"},
    "SGDClassifier":        {"color":"#9B59B6","desc":"Gradient stochastique - rapide sur grands corpus"},
    "SVM (LinearSVC)":      {"color":"#0288D1","desc":"Maximise la marge de separation TF-IDF"},
    "Decision Tree":        {"color":"#558B2F","desc":"Arbre de decision - tres interpretable"},
    "Random Forest":        {"color":"#C62828","desc":"Foret d arbres - bagging, anti-overfit"},
    "Logistic Regression":  {"color":"#3949AB","desc":"Regression logistique - probabilites calibrees"},
}

# ── Text cleaning — pipeline notebook (lemmatisation + NLTK stopwords) ────────
def clean_text(text: str) -> str:
    """Pipeline de nettoyage identique au notebook : URL, ponctuation, lower, stopwords + lemmatisation."""
    # 1. Supprimer les URLs
    text = re.sub(r'https?://\S+|www\.\S+', '', str(text))
    # 2. Garder uniquement les lettres
    text = re.sub(r'[^a-zA-Z\s]', ' ', text)
    # 3. Minuscules
    text = text.lower()
    # 4. Stopwords + lemmatisation
    tokens = text.split()
    if HAS_NLTK and _lemmatizer:
        tokens = [
            _lemmatizer.lemmatize(tok)
            for tok in tokens
            if tok not in STOP_WORDS and len(tok) > 1
        ]
    else:
        tokens = [t for t in tokens if t not in STOP_WORDS and len(t) > 2]
    return ' '.join(tokens)

def get_word_frequencies(text: str, top_n=30):
    """Return top N word frequencies from raw text (excluding stopwords)."""
    tokens = re.sub(r'[^a-zA-Z\s]', ' ', text.lower()).split()
    tokens = [t for t in tokens if t not in STOP_WORDS and len(t) > 2]
    from collections import Counter
    counts = Counter(tokens)
    total = sum(counts.values()) or 1
    return [
        {"word": w, "count": c, "pct": round(c / total * 100, 2)}
        for w, c in counts.most_common(top_n)
    ]

# ── Chargement des modeles reels (produits par le notebook) ──────────────────
def load_real_models():
    """
    Charge le vectoriseur TF-IDF, le vectoriseur TF-IDF (XGBoost) et les 7 modeles
    entraines dans le notebook, depuis le dossier models/ (joblib.dump).

    Arborescence attendue (a cote de app.py) :
        models/
            tfidf_vectorizer.pkl
            tfidf_vectorizer_xgb.pkl
            naive_bayes.pkl
            xgboost.pkl
            sgd.pkl
            svm_linearsvc.pkl
            decision_tree.pkl
            random_forest.pkl
            logistic_regression.pkl
            model_stats.json   (optionnel — accuracy de chaque modele)
    """
    global MODELS, VECTORIZER, VECTORIZER_XGB, MODEL_STATS, IS_READY, LOAD_ERRORS
    LOAD_ERRORS = []

    if not os.path.isdir(MODELS_DIR):
        LOAD_ERRORS.append(f"Dossier '{MODELS_DIR}' introuvable.")
        IS_READY = False
        return

    # --- Vectoriseurs ---
    vec_path = os.path.join(MODELS_DIR, VECTORIZER_FILE)
    if os.path.exists(vec_path):
        try:
            VECTORIZER = joblib.load(vec_path)
        except Exception as e:
            LOAD_ERRORS.append(f"{VECTORIZER_FILE}: {e}")
    else:
        LOAD_ERRORS.append(f"{VECTORIZER_FILE} manquant")

    vec_xgb_path = os.path.join(MODELS_DIR, VECTORIZER_XGB_FILE)
    if os.path.exists(vec_xgb_path):
        try:
            VECTORIZER_XGB = joblib.load(vec_xgb_path)
        except Exception as e:
            LOAD_ERRORS.append(f"{VECTORIZER_XGB_FILE}: {e}")
    else:
        LOAD_ERRORS.append(f"{VECTORIZER_XGB_FILE} manquant")

    # --- Modeles ---
    for display_name, filename in MODEL_FILES.items():
        if display_name == "XGBoost" and not HAS_XGB:
            continue
        path = os.path.join(MODELS_DIR, filename)
        if not os.path.exists(path):
            LOAD_ERRORS.append(f"{filename} manquant")
            continue
        try:
            MODELS[display_name] = joblib.load(path)
            print(f"  [OK] {display_name:<22} <- {filename}")
        except Exception as e:
            LOAD_ERRORS.append(f"{filename}: {e}")

    # --- Stats (accuracy) ---
    stats_path = os.path.join(MODELS_DIR, STATS_FILE)
    if os.path.exists(stats_path):
        try:
            with open(stats_path, "r", encoding="utf-8") as f:
                MODEL_STATS = json.load(f)
        except Exception as e:
            LOAD_ERRORS.append(f"{STATS_FILE}: {e}")
            MODEL_STATS = {name: 0 for name in MODELS}
    else:
        # Pas de fichier de stats fourni -> valeurs a 0 (affichees mais non bloquantes)
        MODEL_STATS = {name: MODEL_STATS.get(name, 0) for name in MODELS}

    IS_READY = (
        VECTORIZER is not None
        and len(MODELS) > 0
        and ("XGBoost" not in MODELS or VECTORIZER_XGB is not None)
    )

    if IS_READY:
        print(f"Modeles reels charges depuis {MODELS_DIR} | "
              f"{len(MODELS)} modeles | NLTK lemmatisation: {HAS_NLTK}")
    else:
        print("Echec du chargement des modeles reels :")
        for err in LOAD_ERRORS:
            print(f"   - {err}")

# ── Routes ────────────────────────────────────────────────────────────────────
@app.route("/api/status")
def status():
    return jsonify({
        "ready":       IS_READY,
        "models":      list(MODELS.keys()),
        "stats":       MODEL_STATS,
        "meta":        MODEL_META,
        "has_shap":    HAS_SHAP,
        "has_pdf":     HAS_PDF,
        "has_docx":    HAS_DOCX,
        "has_nltk":    HAS_NLTK,
        "models_dir":  MODELS_DIR,
        "load_errors": LOAD_ERRORS,
        "source":      "notebook (modeles reels charges depuis models/)",
    })

@app.route("/api/predict", methods=["POST"])
def predict():
    if not IS_READY:
        return jsonify({
            "error": "Modeles non charges. Verifiez le dossier 'models/' (voir /api/status -> load_errors)."
        }), 503

    try:
        data     = request.get_json(force=True) or {}
        text     = (data.get("text") or "").strip()
        selected = data.get("models", list(MODELS.keys()))
        if not text or len(text) < 20:
            return jsonify({"error": "Texte trop court (min 20 caracteres)"}), 400

        cleaned = clean_text(text)
        results      = []
        model_errors = []

        for name in selected:
            if name not in MODELS:
                continue
            try:
                model = MODELS[name]
                t0  = time.time()
                vec = VECTORIZER_XGB.transform([cleaned]) if name == "XGBoost" else VECTORIZER.transform([cleaned])
                pred = model.predict(vec)[0]
                ms   = round((time.time() - t0) * 1000, 1)

                if hasattr(model, "predict_proba"):
                    proba = model.predict_proba(vec)[0]
                    conf_fake = round(float(proba[0]) * 100, 1)
                    conf_real = round(float(proba[1]) * 100, 1)
                elif hasattr(model, "decision_function"):
                    df_val = model.decision_function(vec)[0]
                    sig    = 1 / (1 + np.exp(-abs(float(df_val))))
                    conf_real = round(sig * 100 if pred == 1 else (1-sig)*100, 1)
                    conf_fake = round(100 - conf_real, 1)
                else:
                    conf_fake = 80.0 if pred == 0 else 20.0
                    conf_real = 100 - conf_fake

                results.append({
                    "model":    name,
                    "label":    int(pred),
                    "verdict":  "FAKE" if pred == 0 else "REAL",
                    "conf_fake": conf_fake,
                    "conf_real": conf_real,
                    "time_ms":  ms,
                    "accuracy": MODEL_STATS.get(name, 0),
                    "color":    MODEL_META.get(name, {}).get("color", "#888"),
                    "desc":     MODEL_META.get(name, {}).get("desc", ""),
                })
            except Exception as e:
                # Un modele en erreur ne doit pas faire echouer toute la requete
                model_errors.append(f"{name}: {e}")

        if not results:
            return jsonify({
                "error": "Aucun modele n'a pu produire de prediction.",
                "model_errors": model_errors,
            }), 500

        votes         = [r["label"] for r in results]
        fake_votes    = votes.count(0)
        real_votes    = votes.count(1)
        ensemble_label = 0 if fake_votes > real_votes else 1
        ensemble_conf  = round(max(fake_votes, real_votes) / max(len(votes), 1) * 100, 1)
        word_freq      = get_word_frequencies(text)

        return jsonify({
            "results":          results,
            "ensemble_label":   ensemble_label,
            "ensemble_verdict": "FAKE" if ensemble_label == 0 else "REAL",
            "ensemble_conf":    ensemble_conf,
            "fake_votes":       fake_votes,
            "real_votes":       real_votes,
            "total_models":     len(results),
            "cleaned_preview":  cleaned[:200] + "..." if len(cleaned) > 200 else cleaned,
            "word_frequencies": word_freq,
            "model_errors":     model_errors,
        })
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"error": f"Erreur interne : {e}"}), 500

@app.route("/api/shap", methods=["POST"])
def shap_explain():
    """Top feature weights via coefficients Logistic Regression (proxy SHAP)."""
    if not IS_READY:
        return jsonify({"error": "Modeles non charges"}), 503
    data = request.get_json(force=True)
    text = data.get("text", "").strip()
    if not text or len(text) < 20:
        return jsonify({"error": "Texte trop court"}), 400

    cleaned    = clean_text(text)
    model_name = "Logistic Regression" if "Logistic Regression" in MODELS else next(iter(MODELS))
    model      = MODELS[model_name]
    vec        = VECTORIZER.transform([cleaned])
    feature_names = VECTORIZER.get_feature_names_out()

    try:
        cx = vec.tocsr()
        nonzero_idx = cx.nonzero()[1]
        tfidf_vals  = np.array(cx[0, nonzero_idx]).flatten()

        if hasattr(model, 'coef_'):
            coefs         = model.coef_[0]
            contributions = tfidf_vals * coefs[nonzero_idx]
        else:
            contributions = tfidf_vals

        top_idx  = np.argsort(np.abs(contributions))[-20:][::-1]
        features = []
        for i in top_idx:
            orig_i = nonzero_idx[i]
            features.append({
                "word":      str(feature_names[orig_i]),
                "value":     round(float(contributions[i]), 4),
                "tfidf":     round(float(tfidf_vals[i]), 4),
                "direction": "fake" if contributions[i] < 0 else "real"
            })
        return jsonify({"features": features, "model": model_name})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/extract-file", methods=["POST"])
def extract_file():
    """Extract text from uploaded PDF, DOCX or TXT (base64 encoded)."""
    data      = request.get_json(force=True)
    file_b64  = data.get("data", "")
    file_type = data.get("type", "").lower()

    try:
        file_bytes = base64.b64decode(file_b64)
    except Exception:
        return jsonify({"error": "Invalid base64 data"}), 400

    extracted_text = ""

    if file_type == "pdf":
        try:
            import pdfplumber
            with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
                for page in pdf.pages:
                    t = page.extract_text()
                    if t: extracted_text += t + "\n"
        except ImportError:
            try:
                import pypdf
                reader = pypdf.PdfReader(io.BytesIO(file_bytes))
                for page in reader.pages:
                    extracted_text += page.extract_text() + "\n"
            except ImportError:
                return jsonify({"error": "pdfplumber ou pypdf requis"}), 500
        except Exception as e:
            return jsonify({"error": f"Erreur PDF: {str(e)}"}), 500

    elif file_type in ("docx", "doc"):
        try:
            import docx as python_docx
            doc = python_docx.Document(io.BytesIO(file_bytes))
            extracted_text = "\n".join(p.text for p in doc.paragraphs if p.text.strip())
        except ImportError:
            return jsonify({"error": "python-docx requis: pip install python-docx"}), 500
        except Exception as e:
            return jsonify({"error": f"Erreur DOCX: {str(e)}"}), 500

    elif file_type == "txt":
        try:
            extracted_text = file_bytes.decode("utf-8", errors="replace")
        except Exception as e:
            return jsonify({"error": str(e)}), 500
    else:
        return jsonify({"error": f"Format non supporte: {file_type}"}), 400

    extracted_text = extracted_text.strip()
    if not extracted_text:
        return jsonify({"error": "Aucun texte extrait du fichier"}), 400

    return jsonify({
        "text":    extracted_text,
        "length":  len(extracted_text),
        "preview": extracted_text[:300] + "..." if len(extracted_text) > 300 else extracted_text
    })

@app.route("/api/models")
def get_models():
    out = []
    for name, meta in MODEL_META.items():
        if name in MODELS:
            out.append({"name": name, "accuracy": MODEL_STATS.get(name, 0), **meta})
    return jsonify(out)

@app.route("/")
def index():
    return jsonify({"status": "VeritAI Fake News Detection API v2.2 — modeles reels du notebook"})

# ── Gestion globale des erreurs (toujours renvoyer du JSON) ──────────────────
@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Route introuvable"}), 404

@app.errorhandler(500)
def server_error(e):
    return jsonify({"error": f"Erreur serveur interne : {e}"}), 500

if __name__ == "__main__":
    load_real_models()
    app.run(debug=False, port=5000)
