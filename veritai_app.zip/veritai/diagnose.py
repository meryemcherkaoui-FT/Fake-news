"""
Script de diagnostic VeritAI
Lance : python diagnose.py
Affiche, pour chaque modele, s'il se charge et predit correctement,
et imprime la trace complete de l'erreur si un modele echoue.
"""
import os, sys, traceback
import joblib

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODELS_DIR = os.path.join(BASE_DIR, "models")

print("Python:", sys.version)
try:
    import sklearn
    print("scikit-learn:", sklearn.__version__)
except Exception as e:
    print("scikit-learn: ERREUR", e)

try:
    import numpy
    print("numpy:", numpy.__version__)
except Exception as e:
    print("numpy: ERREUR", e)

try:
    import xgboost
    print("xgboost:", xgboost.__version__)
except Exception as e:
    print("xgboost: NON INSTALLE (", e, ")")

print("joblib:", joblib.__version__)
print("-" * 60)

MODEL_FILES = {
    "Naive Bayes":          "naive_bayes.pkl",
    "XGBoost":              "xgboost.pkl",
    "SGDClassifier":        "sgd.pkl",
    "SVM (LinearSVC)":      "svm_linearsvc.pkl",
    "Decision Tree":        "decision_tree.pkl",
    "Random Forest":        "random_forest.pkl",
    "Logistic Regression":  "logistic_regression.pkl",
}

print("Chargement du vectoriseur TF-IDF...")
try:
    vec = joblib.load(os.path.join(MODELS_DIR, "tfidf_vectorizer.pkl"))
    print("  OK -", len(vec.get_feature_names_out()), "features")
except Exception:
    print("  ECHEC")
    traceback.print_exc()
    sys.exit(1)

X = vec.transform(["this is a simple test sentence about politics and economy today"])

print("-" * 60)
for name, filename in MODEL_FILES.items():
    path = os.path.join(MODELS_DIR, filename)
    print(f"--- {name} ({filename}) ---")
    if not os.path.exists(path):
        print("  fichier manquant")
        continue
    try:
        model = joblib.load(path)
        print("  chargement OK -", type(model))
    except Exception:
        print("  ECHEC AU CHARGEMENT")
        traceback.print_exc()
        continue

    try:
        if name == "XGBoost":
            vec_xgb = joblib.load(os.path.join(MODELS_DIR, "tfidf_vectorizer_xgb.pkl"))
            Xm = vec_xgb.transform(["this is a simple test sentence about politics and economy today"])
        else:
            Xm = X
        pred = model.predict(Xm)
        print("  predict OK ->", pred)
        if hasattr(model, "predict_proba"):
            proba = model.predict_proba(Xm)
            print("  predict_proba OK ->", proba)
        elif hasattr(model, "decision_function"):
            df = model.decision_function(Xm)
            print("  decision_function OK ->", df)
    except Exception:
        print("  ECHEC A LA PREDICTION")
        traceback.print_exc()

print("-" * 60)
print("Termine.")
